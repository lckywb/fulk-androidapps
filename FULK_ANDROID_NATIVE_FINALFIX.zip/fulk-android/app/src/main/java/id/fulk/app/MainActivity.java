package id.fulk.app;

import android.app.*;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    final String URL = "https://superb-pavlova-0fb91f.netlify.app/";
    final String[] PKGS = {"com.instagram.android","com.zhiliaoapp.musically","com.ss.android.ugc.trill","com.google.android.youtube"};
    final String[] NAMES = {"Instagram","TikTok","TikTok","YouTube"};

    @Override public void onCreate(Bundle b){ super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient(){ @Override public void onPageFinished(WebView v,String url){ super.onPageFinished(v,url); injectNativeUI(v); }});
        web.addJavascriptInterface(new FulkBridge(this), "FULK_NATIVE");
        web.loadUrl(URL);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},44);
    }
    public void openUsage(){ startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
    public boolean usageGranted(){ try { android.app.AppOpsManager appOps=(android.app.AppOpsManager)getSystemService(APP_OPS_SERVICE); int mode=appOps.unsafeCheckOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,android.os.Process.myUid(),getPackageName()); return mode==android.app.AppOpsManager.MODE_ALLOWED; } catch(Exception e){ return false; } }
    public Map<String,Long> usageToday(){ Map<String,Long> out=new LinkedHashMap<>(); UsageStatsManager u=(UsageStatsManager)getSystemService(USAGE_STATS_SERVICE); Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0); long start=c.getTimeInMillis(), end=System.currentTimeMillis(); try{ for(UsageStats x:u.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,start,end)){ long t=x.getTotalTimeInForeground(); if(t>0){ for(int i=0;i<PKGS.length;i++) if(PKGS[i].equals(x.getPackageName())) out.put(NAMES[i],Math.max(out.getOrDefault(NAMES[i],0L),t)); }} }catch(Exception ignored){} return out; }

    private void injectNativeUI(WebView v){
        String js = "javascript:(function(){if(window.__FULK_NATIVE_READY)return;window.__FULK_NATIVE_READY=true;"+
        "var p=document.getElementById('pause'); if(p){var c=document.createElement('div');c.className='card';c.id='nativeAndroidCard';c.innerHTML='<h3>Android nyata</h3><p class=\\\"muted\\\">FULK dapat membaca penggunaan aplikasi setelah izin Usage Access diberikan.</p><div id=\\\"nativeUsage\\\" class=\\\"listitem\\\">Memeriksa akses...</div><div class=\\\"grid\\\"><button class=\\\"btn\\\" onclick=\\\"FULK_NATIVE.openUsageAccess()\\\">Izinkan Usage Access</button><button class=\\\"btn secondary\\\" onclick=\\\"FULK_NATIVE.openAccessibilitySettings()\\\">Aktifkan Digital Boundary</button></div></div>';p.insertBefore(c,p.firstChild);}"
        +"var oldPause=window.pauseNow;window.pauseNow=function(min){try{var n=document.getElementById('limitApp').value;var map={Instagram:'com.instagram.android',TikTok:'com.zhiliaoapp.musically','YouTube Shorts':'com.google.android.youtube'};FULK_NATIVE.setPause(map[n]||'com.google.android.youtube',min);}catch(e){}return oldPause(min)};"
        +"var oldSave=window.saveLimit;window.saveLimit=function(){var n=document.getElementById('limitApp').value;var val=Math.max(5,Math.min(240,Number(document.getElementById('limitMinutes').value)||30));var map={Instagram:'com.instagram.android',TikTok:'com.zhiliaoapp.musically','YouTube Shorts':'com.google.android.youtube'};try{FULK_NATIVE.setDailyLimit(map[n],val)}catch(e){}return oldSave()};"
        +"window.setAndroidAlarm=function(){try{var a=document.getElementById('alarmTime').value.split(':').map(Number),d=new Date();d.setHours(a[0],a[1],0,0);if(d.getTime()<=Date.now())d.setDate(d.getDate()+1);var msg=document.getElementById('alarmMessage').value||'Waktunya kembali ke fokus — FULK';FULK_NATIVE.scheduleAlarm(d.getTime(),msg);toast('Alarm Android dijadwalkan.')}catch(e){toast('Gagal menjadwalkan alarm.')}};"
        +"document.querySelectorAll('a.social').forEach(function(a){a.addEventListener('click',function(e){var h=a.href||'';var p=h.indexOf('instagram')>=0?'com.instagram.android':h.indexOf('tiktok')>=0?'com.zhiliaoapp.musically':'com.google.android.youtube';try{if(FULK_NATIVE.openApp){e.preventDefault();FULK_NATIVE.openApp(p)}}catch(x){}})});"
        +"function upd(){try{var j=JSON.parse(FULK_NATIVE.getUsageJson());var s=Object.keys(j).map(function(k){return k+' — '+Math.round(j[k]/60000)+' menit'}).join('<br>');var el=document.getElementById('nativeUsage');if(el)el.innerHTML=FULK_NATIVE.hasUsageAccess()?s||'Belum ada penggunaan tercatat hari ini.':'Usage Access belum diberikan.'}catch(e){}};upd();setInterval(upd,30000);})();";
        v.evaluateJavascript(js,null);
    }

    public class FulkBridge {
        Context ctx; FulkBridge(Context c){ctx=c;}
        @JavascriptInterface public boolean hasUsageAccess(){return usageGranted();}
        @JavascriptInterface public void openUsageAccess(){openUsage();}
        @JavascriptInterface public String getUsageJson(){ Map<String,Long> m=usageToday(); StringBuilder b=new StringBuilder("{"); boolean first=true; for(Map.Entry<String,Long> e:m.entrySet()){ if(!first)b.append(','); first=false; b.append("\"").append(e.getKey()).append("\":").append(e.getValue()); } b.append('}'); return b.toString(); }
        @JavascriptInterface public void setDailyLimit(String packageName,long minutes){ getSharedPreferences("fulk",0).edit().putLong("limit_"+packageName,minutes).apply(); }
        @JavascriptInterface public void setPause(String packageName,long minutes){ getSharedPreferences("fulk",0).edit().putLong("pause_"+packageName,System.currentTimeMillis()+minutes*60000L).apply(); }
        @JavascriptInterface public boolean isPaused(String packageName){ return getSharedPreferences("fulk",0).getLong("pause_"+packageName,0)>System.currentTimeMillis(); }
        @JavascriptInterface public void openApp(String packageName){ try{Intent i=getPackageManager().getLaunchIntentForPackage(packageName); if(i!=null)startActivity(i); else startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://"+packageName)));}catch(Exception ignored){} }
        @JavascriptInterface public void openAccessibilitySettings(){startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}
        @JavascriptInterface public boolean accessibilityEnabled(){String s=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES); return s!=null && s.contains(getPackageName()+"/"+BlockAccessibilityService.class.getName());}
        @JavascriptInterface public void scheduleAlarm(long triggerMillis,String title){
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); Intent i=new Intent(MainActivity.this,AlarmReceiver.class).putExtra("title",title); PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,(int)(triggerMillis%100000),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){ startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); return; }
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,triggerMillis,pi);
        }
    }
}
