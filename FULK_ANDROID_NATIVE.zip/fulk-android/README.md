# FULK Android Native

Native Android shell for the FULK PWA. It loads the Netlify FULK web app and exposes a JavaScript bridge for:
- Usage Access / UsageStatsManager
- daily limits for Instagram, TikTok and YouTube
- pause windows
- AccessibilityService overlay for Digital Boundary
- Android exact alarm scheduling

## Build without Android Studio

Upload this project to a GitHub repository. Open **Actions → Build FULK Android → Run workflow**. The generated `FULK-debug-apk` is available under the workflow run's Artifacts.

## Required user permissions

1. Usage Access: Settings → Apps → Special app access → Usage access → FULK.
2. Accessibility: Settings → Accessibility → Installed apps → FULK.
3. Notifications on Android 13+.
4. Exact alarm permission may be requested on Android 12+/13+ devices when scheduling exact alarms.

The AccessibilityService is optional and user-enabled. The app does not claim to silently disable other apps; it displays a FULK pause overlay when a selected app is in a paused/over-limit state.
