package id.fulk.app;
import android.app.*; import android.content.*; import android.os.*;
public class AlarmReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){ String title=i.getStringExtra("title"); NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); String ch="fulk_alarm"; if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(ch,"FULK Focus",NotificationManager.IMPORTANCE_HIGH)); Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c); b.setSmallIcon(id.fulk.app.R.drawable.ic_fulk).setContentTitle("FULK").setContentText(title==null?"Waktunya kembali fokus.":title).setAutoCancel(true); nm.notify((int)System.currentTimeMillis(),b.build()); }
}
