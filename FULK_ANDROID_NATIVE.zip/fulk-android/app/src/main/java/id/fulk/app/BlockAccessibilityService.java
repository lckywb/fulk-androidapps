package id.fulk.app;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.widget.*;
import android.content.*;

public class BlockAccessibilityService extends AccessibilityService {
    View overlay; WindowManager wm;
    final String[] targets={"com.instagram.android","com.zhiliaoapp.musically","com.ss.android.ugc.trill","com.google.android.youtube"};
    @Override public void onServiceConnected(){ super.onServiceConnected(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){ if(e==null||e.getPackageName()==null)return; String pkg=e.getPackageName().toString(); boolean target=false; for(String x:targets)if(x.equals(pkg))target=true; if(!target){remove();return;} long until=getSharedPreferences("fulk",0).getLong("pause_"+pkg,0); long limit=getSharedPreferences("fulk",0).getLong("limit_"+pkg,0); boolean over=false; if(limit>0){ try{ android.app.usage.UsageStatsManager u=(android.app.usage.UsageStatsManager)getSystemService(USAGE_STATS_SERVICE); java.util.Calendar c=java.util.Calendar.getInstance(); c.set(java.util.Calendar.HOUR_OF_DAY,0);c.set(java.util.Calendar.MINUTE,0);c.set(java.util.Calendar.SECOND,0);c.set(java.util.Calendar.MILLISECOND,0); long total=0; for(android.app.usage.UsageStats st:u.queryUsageStats(android.app.usage.UsageStatsManager.INTERVAL_DAILY,c.getTimeInMillis(),System.currentTimeMillis())) if(pkg.equals(st.getPackageName())) total+=st.getTotalTimeInForeground(); over=total>=limit*60000L; }catch(Exception ignored){} } if(until>System.currentTimeMillis()||over)show(); else remove(); }
    void show(){ if(overlay!=null)return; LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(55,80,55,55); box.setGravity(Gravity.CENTER); box.setBackgroundColor(Color.rgb(6,20,26)); TextView t=new TextView(this);t.setText("⏸  FULK PAUSE\n\nBahtera digitalmu sedang dijeda.\n\nGunakan jeda ini untuk kembali pada hal yang sedang kamu bangun.");t.setTextColor(Color.WHITE);t.setTextSize(20);t.setGravity(Gravity.CENTER); box.addView(t,new LinearLayout.LayoutParams(-1,-2)); Button b=new Button(this);b.setText("Kembali ke FULK");b.setOnClickListener(v->{remove();Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);startActivity(i);}); box.addView(b,new LinearLayout.LayoutParams(-1,-2)); overlay=box; int type=WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY; WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,type,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); wm.addView(overlay,lp); }
    void remove(){if(overlay!=null){try{wm.removeView(overlay);}catch(Exception ignored){}overlay=null;}}
    @Override public void onInterrupt(){remove();}
    @Override public void onDestroy(){remove();super.onDestroy();}
}
