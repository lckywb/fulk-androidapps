package id.fulk.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.widget.*;
import android.content.*;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import java.util.*;

public class BlockAccessibilityService extends AccessibilityService {
    private View overlay; private WindowManager wm; private String activePackage="";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final String[] targets={"com.instagram.android","com.zhiliaoapp.musically","com.ss.android.ugc.trill","com.google.android.youtube"};
    private final Runnable boundaryTick=new Runnable(){ public void run(){ if(activePackage!=null && isTarget(activePackage)) checkAndShow(activePackage); handler.postDelayed(this,3000); }};

    @Override public void onServiceConnected(){ super.onServiceConnected(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); AccessibilityServiceInfo info=getServiceInfo(); if(info!=null){ info.eventTypes=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_WINDOWS_CHANGED; info.feedbackType=AccessibilityServiceInfo.FEEDBACK_GENERIC; info.notificationTimeout=100; info.packageNames=targets; info.flags=AccessibilityServiceInfo.DEFAULT; setServiceInfo(info);} handler.post(boundaryTick); }
    private boolean isTarget(String pkg){ for(String x:targets) if(x.equals(pkg)) return true; return false; }
    private long todayUsage(String pkg){ try{ UsageStatsManager u=(UsageStatsManager)getSystemService(USAGE_STATS_SERVICE); Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0); long total=0; for(UsageStats st:u.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,c.getTimeInMillis(),System.currentTimeMillis())) if(pkg.equals(st.getPackageName())) total+=st.getTotalTimeInForeground(); return total;}catch(Exception ignored){return 0;} }
    private void checkAndShow(String pkg){ SharedPreferences p=getSharedPreferences("fulk",MODE_PRIVATE); long until=p.getLong("pause_"+pkg,0), limit=p.getLong("limit_"+pkg,0); boolean over=limit>0 && todayUsage(pkg)>=limit*60000L; if(until>System.currentTimeMillis()||over)show(); else if(!over && until<=System.currentTimeMillis())remove(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){ if(e==null||e.getPackageName()==null)return; String pkg=e.getPackageName().toString(); if(!isTarget(pkg))return; activePackage=pkg; checkAndShow(pkg); }
    private void show(){ if(overlay!=null||wm==null)return; LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(48,72,48,48); box.setGravity(Gravity.CENTER); box.setBackgroundColor(Color.rgb(3,20,26));
        TextView t=new TextView(this); t.setText("🌊  FULK PAUSE\n\nBahtera digitalmu sedang dijeda.\n\nBatas penggunaanmu telah tercapai. Gunakan jeda ini untuk kembali pada hal yang sedang kamu bangun."); t.setTextColor(Color.WHITE); t.setTextSize(20); t.setGravity(Gravity.CENTER); box.addView(t,new LinearLayout.LayoutParams(-1,-2));
        Button b=new Button(this); b.setText("Kembali ke FULK"); b.setOnClickListener(v->{remove(); Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);startActivity(i);}); box.addView(b,new LinearLayout.LayoutParams(-1,-2));
        overlay=box; WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); wm.addView(overlay,lp); }
    private void remove(){if(overlay!=null){try{wm.removeView(overlay);}catch(Exception ignored){}overlay=null;}}
    @Override public void onInterrupt(){remove();} @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);remove();super.onDestroy();}
}
