package id.fulk.app;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.*;
import java.util.*;

public class AlarmReceiver extends BroadcastReceiver {
    static final String CHANNEL="fulk_flame_v2";
    @Override public void onReceive(Context c,Intent i){
        String kind=i.getStringExtra("kind");
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            Uri sound=Uri.parse("android.resource://"+c.getPackageName()+"/"+R.raw.fulk_chime);
            AudioAttributes aa=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Api Bahtera",NotificationManager.IMPORTANCE_DEFAULT); ch.setSound(sound,aa); nm.createNotificationChannel(ch);
        }
        String text;
        if("streak".equals(kind)){
            int streak=c.getSharedPreferences("fulk",0).getInt("streak",0);
            text=streak>0?"Api Bahteramu sudah menyala "+streak+" hari. Sempatkan check-in hari ini.":"Satu menit untuk menyalakan Api Bahtera hari ini.";
        } else text=i.getStringExtra("title");
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c).setSound(Uri.parse("android.resource://"+c.getPackageName()+"/"+R.raw.fulk_chime));
        b.setSmallIcon(R.drawable.ic_fulk).setContentTitle("FULK • Bangun Bahteramu").setContentText(text==null?"Kembali ke fokus.":text).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER);
        nm.notify("streak".equals(kind)?1901:(int)(System.currentTimeMillis()%100000),b.build());
        if("streak".equals(kind)) scheduleNext(c);
    }
    static void scheduleNext(Context c){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); Calendar cal=Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR,1); cal.set(Calendar.HOUR_OF_DAY,19);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);
        Intent in=new Intent(c,AlarmReceiver.class).putExtra("kind","streak"); PendingIntent pi=PendingIntent.getBroadcast(c,1900,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi); else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
    }
}
