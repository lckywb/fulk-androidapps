package id.fulk.app;

import android.Manifest;
import android.app.*;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    final String URL = "https://superb-pavlova-0fb91f.netlify.app/";
    final String[] PKGS = {"com.instagram.android","com.zhiliaoapp.musically","com.ss.android.ugc.trill","com.google.android.youtube"};
    final String[] NAMES = {"Instagram","TikTok","TikTok","YouTube"};
    final String PREF="fulk";
    final int NOTIF_REQ=44;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        createNotificationChannels();
        web=new WebView(this); setContentView(web);
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient(){ @Override public void onPageFinished(WebView v,String url){ super.onPageFinished(v,url); injectNativeUI(v); }});
        web.addJavascriptInterface(new FulkBridge(this), "FULK_NATIVE");
        web.loadUrl(URL);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF_REQ);
        scheduleDailyReminder(19,0);
    }

    void createNotificationChannels(){
        if(Build.VERSION.SDK_INT<26) return;
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Uri sound=Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.fulk_chime);
        AudioAttributes aa=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        NotificationChannel flame=new NotificationChannel("fulk_flame_v2","Api Bahtera",NotificationManager.IMPORTANCE_DEFAULT);
        flame.setDescription("Pengingat lembut untuk menjaga kebiasaan digital FULK tetap menyala.");
        flame.setSound(sound,aa);
        nm.createNotificationChannel(flame);
        NotificationChannel focus=new NotificationChannel("fulk_focus_v2","FULK Focus",NotificationManager.IMPORTANCE_HIGH);
        focus.setDescription("Pengingat waktu fokus dan jeda."); focus.setSound(sound,aa);
        nm.createNotificationChannel(focus);
    }

    public void openUsage(){ startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
    public boolean usageGranted(){ try { android.app.AppOpsManager appOps=(android.app.AppOpsManager)getSystemService(APP_OPS_SERVICE); int mode=appOps.unsafeCheckOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,Process.myUid(),getPackageName()); return mode==android.app.AppOpsManager.MODE_ALLOWED; } catch(Exception e){ return false; } }
    public Map<String,Long> usageToday(){
        Map<String,Long> out=new LinkedHashMap<>(); UsageStatsManager u=(UsageStatsManager)getSystemService(USAGE_STATS_SERVICE);
        Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        long start=c.getTimeInMillis(), end=System.currentTimeMillis();
        try{ for(UsageStats x:u.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,start,end)){ long t=x.getTotalTimeInForeground(); if(t>0){ for(int i=0;i<PKGS.length;i++) if(PKGS[i].equals(x.getPackageName())) out.put(NAMES[i],out.getOrDefault(NAMES[i],0L)+t); }} }catch(Exception ignored){}
        return out;
    }

    String today(){ return new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()); }
    String yesterday(){ Calendar c=Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR,-1); return new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime()); }
    void checkIn(){
        SharedPreferences p=getSharedPreferences(PREF,0); String d=p.getString("last_checkin",""); String t=today();
        if(t.equals(d)) return;
        int streak=p.getInt("streak",0); streak = yesterday().equals(d) ? streak+1 : 1;
        p.edit().putString("last_checkin",t).putInt("streak",streak).apply();
    }
    int getStreak(){ return getSharedPreferences(PREF,0).getInt("streak",0); }

    public void scheduleDailyReminder(int hour,int minute){
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,hour); c.set(Calendar.MINUTE,minute); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
        if(c.getTimeInMillis()<=System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR,1);
        Intent i=new Intent(this,AlarmReceiver.class).putExtra("kind","streak");
        PendingIntent pi=PendingIntent.getBroadcast(this,1900,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
    }

    void notifyTest(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF_REQ); return; }
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"fulk_flame_v2"):new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_fulk).setContentTitle("Api Bahtera menyala 🔥").setContentText("Satu menit untuk kembali sadar pada arus informasimu.").setAutoCancel(true);
        nm.notify(9101,b.build());
    }

    private void injectNativeUI(WebView v){
        String js=""+
        "javascript:(function(){if(window.__FULK_NATIVE_READY)return;window.__FULK_NATIVE_READY=true;"+
        "var style=document.createElement('style');style.textContent=`body{background:linear-gradient(180deg,#041b23 0%,#062c36 52%,#041820 100%)!important;color:#edfdfa!important}.card,.panel,.feature-card{border-color:rgba(105,221,182,.22)!important;background:rgba(9,43,52,.86)!important;box-shadow:0 18px 50px rgba(0,0,0,.18)!important}.btn{border-radius:18px!important}.native-sea{background:linear-gradient(135deg,#073844,#0a5260);border:1px solid rgba(105,221,182,.3);border-radius:24px;padding:20px;margin:14px 0;box-shadow:0 16px 45px rgba(0,0,0,.2)}.native-kicker{letter-spacing:2px;color:#69ddb6;font-weight:700;font-size:12px}.native-title{font-size:25px;font-weight:800;margin:8px 0}.native-sub{opacity:.78;line-height:1.55}.native-row{display:flex;gap:10px;flex-wrap:wrap}.native-pill{padding:8px 12px;border-radius:999px;background:rgba(105,221,182,.12);color:#9deed5}.native-btn{border:0;padding:12px 16px;border-radius:15px;background:#69ddb6;color:#052028;font-weight:800}.native-btn.alt{background:rgba(255,255,255,.08);color:#edfdfa;border:1px solid rgba(255,255,255,.1)}.native-campaign{position:fixed;inset:0;z-index:99999;background:#03141a;color:#edfdfa;display:none;overflow:auto}.native-scene{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:34px;text-align:center;background:radial-gradient(circle at 50% 30%,rgba(105,221,182,.13),transparent 35%),linear-gradient(180deg,#03141a,#063743)}.native-scene-inner{max-width:650px}.native-ark{font-size:74px;margin-bottom:20px;filter:drop-shadow(0 10px 25px rgba(0,0,0,.35))}.native-scene h1{font-size:34px;line-height:1.08;margin:12px 0}.native-scene p{font-size:17px;line-height:1.7;opacity:.82}.native-progress{position:fixed;top:0;left:0;height:4px;background:#69ddb6;z-index:100000}.native-close{position:fixed;right:18px;top:18px;border:1px solid rgba(255,255,255,.18);background:rgba(0,0,0,.25);color:#fff;border-radius:999px;padding:10px 14px;z-index:100001}.native-campaign-nav{position:fixed;bottom:22px;left:50%;transform:translateX(-50%);z-index:100001}`;document.head.appendChild(style);"+
        "var p=document.getElementById('pause'); if(p){"+
        "var c=document.createElement('div');c.className='native-sea';c.id='nativeAndroidCard';c.innerHTML='<div class=\\\"native-kicker\\\">BAHTERA DIGITAL</div><div class=\\\"native-title\\\">Android nyata</div><div class=\\\"native-sub\\\">FULK dapat membaca penggunaan aplikasi setelah Usage Access diberikan, lalu membantu menjalankan batas digital melalui layanan Android.</div><div id=\\\"nativeUsage\\\" class=\\\"native-sub\\\" style=\\\"margin:12px 0\\\">Memeriksa akses...</div><div class=\\\"native-row\\\"><button class=\\\"native-btn\\\" onclick=\\\"FULK_NATIVE.openUsageAccess()\\\">Usage Access</button><button class=\\\"native-btn alt\\\" onclick=\\\"FULK_NATIVE.openAccessibilitySettings()\\\">Digital Boundary</button></div>';p.insertBefore(c,p.firstChild);"+
        "var s=document.createElement('div');s.className='native-sea';s.innerHTML='<div class=\\\"native-kicker\\\">API BAHTERA 🔥</div><div class=\\\"native-title\\\">Jaga apimu tetap menyala</div><div class=\\\"native-sub\\\">Kebiasaan kecil setiap hari membangun ketahanan digital. Check-in untuk menjaga streak.</div><div id=\\\"nativeStreak\\\" class=\\\"native-pill\\\" style=\\\"display:inline-block;margin:12px 0\\\">0 hari</div><div class=\\\"native-row\\\"><button class=\\\"native-btn\\\" onclick=\\\"FULK_NATIVE.checkIn();updStreak();toast(\\\'Api Bahtera menyala.\\\')\\\">Check-in hari ini</button><button class=\\\"native-btn alt\\\" onclick=\\\"FULK_NATIVE.testNotification()\\\">Tes bunyi notifikasi</button></div>';p.insertBefore(s,c.nextSibling);"+
        "var camp=document.createElement('div');camp.className='native-campaign';camp.id='nativeCampaign';camp.innerHTML='<button class=\\\"native-close\\\" onclick=\\\"closeCampaign()\\\">Tutup</button><div class=\\\"native-progress\\\" id=\\\"campProgress\\\"></div><div id=\\\"campScenes\\\"></div><div class=\\\"native-campaign-nav\\\"><button class=\\\"native-btn\\\" onclick=\\\"nextScene()\\\">Lanjut</button></div>';document.body.appendChild(camp);"+
        "var scenes=["+
        "['🌊','BANJIR INFORMASI','Arus digital bergerak cepat. Bukan semua arus harus dihentikan; yang perlu dibangun adalah kemampuan untuk tetap sadar ketika arus datang.'],"+
        "['🛶','AL-FULK','Dalam QS Hūd [11]:37, al-fulk secara literal menunjuk pada bahtera. Ayat menghubungkan pembuatan bahtera dengan petunjuk dan pengawasan Allah di tengah ancaman banjir.'],"+
        "['⚓','NILAI QURANI','وَاصْنَعِ الْفُلْكَ بِأَعْيُنِنَا وَوَحْيِنَا — bangun sarana keselamatan di bawah petunjuk dan pengawasan. Di sini kita membaca sebuah struktur tindakan, bukan mengganti makna literal al-fulk.'],"+
        "['🧭','TRANSFORMASI NILAI','Dari struktur ayat, penelitian ini membangun dialog: ancaman → petunjuk → tindakan terampil → sarana perlindungan. Nilai Qurani ditransformasikan menjadi prinsip desain ketahanan epistemik.'],"+
        "['🧠','KETAHANAN EPISTEMIK','Dalam banjir informasi, pengguna perlu kemampuan bertindak, sensitivitas terhadap lingkungan informasi, dan kebiasaan yang menjaga kemampuan tersebut. FULK menerjemahkannya menjadi fitur digital.'],"+
        "['🔥','BAHTERA DIGITAL','PAUSE dan Digital Boundary membantu mengatur paparan; Fulk News membantu memeriksa informasi; Focus, Reflection, dan Api Bahtera membantu membangun kebiasaan. Produk ini adalah implementasi konseptual, bukan tafsir literal ayat.'],"+
        "['🌊','BANGUN BAHTERAMU','Kita tidak selalu bisa menghentikan arus informasi. Tetapi kita bisa membangun cara untuk memilih kapan menerima, kapan berhenti, kapan memeriksa, dan kapan bertindak.']"+
        "];var idx=0;function renderScene(){var sc=document.getElementById('campScenes');var a=scenes[idx];sc.innerHTML='<section class=\\\"native-scene\\\"><div class=\\\"native-scene-inner\\\"><div class=\\\"native-ark\\\">'+a[0]+'</div><h1>'+a[1]+'</h1><p>'+a[2]+'</p></div></section>';document.getElementById('campProgress').style.width=((idx+1)/scenes.length*100)+'%';}function nextScene(){idx=(idx+1)%scenes.length;renderScene()}function closeCampaign(){document.getElementById('nativeCampaign').style.display='none'}window.openCampaign=function(){idx=0;renderScene();document.getElementById('nativeCampaign').style.display='block'};"+
        "var home=document.querySelector('body');var cb=document.createElement('div');cb.className='native-sea';cb.innerHTML='<div class=\\\"native-kicker\\\">CAMPAIGN</div><div class=\\\"native-title\\\">Dari al-Fulk menuju Bahtera Digital</div><div class=\\\"native-sub\\\">Lihat transformasi nilai Qurani dari struktur ayat menuju desain ketahanan epistemik.</div><button class=\\\"native-btn\\\" onclick=\\\"openCampaign()\\\">Mulai Campaign</button>';if(p)p.insertBefore(cb,p.children[1]||null);"+
        "function upd(){try{var j=JSON.parse(FULK_NATIVE.getUsageJson());var s=Object.keys(j).map(function(k){return k+' — '+Math.round(j[k]/60000)+' menit'}).join('<br>');var el=document.getElementById('nativeUsage');if(el)el.innerHTML=FULK_NATIVE.hasUsageAccess()?s||'Belum ada penggunaan tercatat hari ini.':'Usage Access belum diberikan.'}catch(e){}}function updStreak(){var el=document.getElementById('nativeStreak');if(el)el.innerHTML=FULK_NATIVE.getStreak()+' hari';}upd();updStreak();setInterval(upd,30000);})();";
        v.evaluateJavascript(js,null);
    }

    public class FulkBridge {
        Context ctx; FulkBridge(Context c){ctx=c;}
        @JavascriptInterface public boolean hasUsageAccess(){return usageGranted();}
        @JavascriptInterface public void openUsageAccess(){openUsage();}
        @JavascriptInterface public String getUsageJson(){ Map<String,Long> m=usageToday(); StringBuilder b=new StringBuilder("{"); boolean first=true; for(Map.Entry<String,Long> e:m.entrySet()){ if(!first)b.append(','); first=false; b.append("\\\"").append(e.getKey()).append("\\\":").append(e.getValue()); } b.append('}'); return b.toString(); }
        @JavascriptInterface public void setDailyLimit(String packageName,long minutes){ getSharedPreferences(PREF,0).edit().putLong("limit_"+packageName,minutes).apply(); }
        @JavascriptInterface public void setPause(String packageName,long minutes){ getSharedPreferences(PREF,0).edit().putLong("pause_"+packageName,System.currentTimeMillis()+minutes*60000L).apply(); }
        @JavascriptInterface public boolean isPaused(String packageName){ return getSharedPreferences(PREF,0).getLong("pause_"+packageName,0)>System.currentTimeMillis(); }
        @JavascriptInterface public void openApp(String packageName){ try{Intent i=getPackageManager().getLaunchIntentForPackage(packageName); if(i!=null)startActivity(i);}catch(Exception ignored){} }
        @JavascriptInterface public void openAccessibilitySettings(){
            SharedPreferences p=getSharedPreferences(PREF,0); SharedPreferences.Editor e=p.edit();
            if(!p.contains("limit_com.instagram.android")) e.putLong("limit_com.instagram.android",30);
            if(!p.contains("limit_com.zhiliaoapp.musically")) e.putLong("limit_com.zhiliaoapp.musically",30);
            if(!p.contains("limit_com.ss.android.ugc.trill")) e.putLong("limit_com.ss.android.ugc.trill",30);
            if(!p.contains("limit_com.google.android.youtube")) e.putLong("limit_com.google.android.youtube",30);
            e.apply(); startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }
        @JavascriptInterface public boolean accessibilityEnabled(){String s=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES); return s!=null && s.contains(getPackageName()+"/"+BlockAccessibilityService.class.getName());}
        @JavascriptInterface public void scheduleAlarm(long triggerMillis,String title){ AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); Intent i=new Intent(MainActivity.this,AlarmReceiver.class).putExtra("kind","focus").putExtra("title",title); PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,(int)(triggerMillis%100000),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){ startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); return; } am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,triggerMillis,pi); }
        @JavascriptInterface public void checkIn(){MainActivity.this.checkIn();}
        @JavascriptInterface public int getStreak(){return MainActivity.this.getStreak();}
        @JavascriptInterface public void testNotification(){notifyTest();}
        @JavascriptInterface public void openNotificationSettings(){ startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName())); }
    }
}
